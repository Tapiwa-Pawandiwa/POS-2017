﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trying_gui
{
    class BoxItems : FoodItem, IEquatable<BoxItems>
    {
        public override double Price
        {
            get
            {
                return price * Quantity;
            }

            set
            {
                price = value;
            }
        }
        public BoxItems(string name, string Des, double price) : base(name, Des, price)
        {

        }

        public override string ToString()
        {
            return string.Format("{2} X {0}   R{1}", Name, Math.Round(Price, 2), Quantity);
        }

        public bool Equals(BoxItems other)
        {
                
            return (BoxDrink.ToLower() == other.BoxDrink.ToLower() && Name.ToLower() == other.Name.ToLower());
        }
    }
}
